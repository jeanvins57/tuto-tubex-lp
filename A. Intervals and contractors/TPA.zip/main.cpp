#include <tubex.h>
#include <math.h>

using namespace std;
using namespace tubex;

// int main()
// {
//   Tube x(Interval(0,10), 0.01, TFunction("cos(t)+abs(t-5)*[-0.1,0.1]"));

//   vibes::beginDrawing();
//   VIBesFigTube fig("My first tube");
//   fig.add_tube(&x, "x");
//   fig.show();
//   vibes::endDrawing();

//   cout << x << endl;
// }

int main()
{
  // A1
    Interval x(8,10);
    Interval y(1,2);
    cout << x/y << endl;

  // A2 - operators example
    cout << Interval(-2,4)*Interval(1,3) << endl;
    cout << Interval(8,10)/Interval(-1,10) << endl;
    // cout << Interval(-2,4)|Interval(6,7) << endl;
    cout << max(Interval(2,7),Interval(1,9)) << endl;
    cout << max(Interval::EMPTY_SET,Interval(1,2)) << endl;
    cout << cos(Interval()) << endl;
    cout << sqr(Interval(-1,4)) << endl;
    cout << (Interval(1,2)*Interval(-1,3))+max(Interval(1,3)&Interval(6,7),Interval(1,2)) << endl;
  // A3 - create 2d box
    Interval a(0, M_PI);
    Interval b(-M_PI/6,M_PI/6);
    // IntervalVector y(a,b);
    // IntervalVector y(Interval(0, M_PI),Interval(-M_PI/6,M_PI/6));
  // A4 - distance function
    IntervalVector x(Interval(0,0),Interval(0,0));
    IntervalVector b(Interval(3,4),Interval(2,3));
    Function f("x","b","sqr( pow((x1-b1),2) + pow((x1-b1),2)")

}