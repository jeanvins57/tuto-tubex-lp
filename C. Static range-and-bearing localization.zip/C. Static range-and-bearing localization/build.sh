#!/bin/bash

mkdir build -p
cd build
cmake ..
make
./Lesson_C
cd ..